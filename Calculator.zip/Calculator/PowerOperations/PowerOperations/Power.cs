﻿using System;
namespace PowerOperations
{
    public class powerOperations
    {
        public double Square(double x)
        {
            return x * x;
        }

        public double Cube(double x)
        {
            return x * x * x;
        }

        public double SquareRoot(double x)
        {
            if (x < 0)
                throw new ArgumentException("Cannot calculate square root of a negative number.");
            return Math.Sqrt(x);
        }

        public double CubeRoot(double x)
        {
            return Math.Pow(x, 1.0 / 3.0);
        }
    }
}
