﻿using System;
using ArthimaticOperations;
using PowerOperations;

class Program
{
    static void Main()
    {
        int a,b;
        double c;
        Console.WriteLine("Scientific Calculator\n");

        ArithmeticOperations arithmetic = new ArithmeticOperations();
        powerOperations power = new powerOperations();

        Console.WriteLine("Select an operation:");
        Console.WriteLine("1. Addition (+)");
        Console.WriteLine("2. Subtraction (-)");
        Console.WriteLine("3. Multiplication (*)");
        Console.WriteLine("4. Division (/)");
        Console.WriteLine("5. Modulus (%)");
        Console.WriteLine("6. Square");
        Console.WriteLine("7. Cube");
        Console.WriteLine("8. Square Root");
        Console.WriteLine("9. Cube Root");

        void input()
        {
            Console.Write("Enter first number");
            a = int.Parse(Console.ReadLine());
            Console.Write("Enter Second number");
            b = int.Parse(Console.ReadLine());
        }

        void powerInput()
            {
                Console.Write("Enter a number");
                c=double.Parse(Console.ReadLine());
            }




        Console.Write("Enter your choice (1-9): ");
        

       
        if (int.TryParse(Console.ReadLine(), out int choice))
        {
            double result = 0;
            bool isPowerOperation = false;

            switch (choice)
            {
                case 1:
                    input();
                    result = arithmetic.Add(a, b);
                    break;

                case 2:
                   input();
                    result = arithmetic.Subtract(a, b);
                    break;

                case 3:
                        input();
                    result = arithmetic.Multiply(a, b);
                    break;

                case 4:
                   input();
                    result = arithmetic.Divide(a, b);
                    break;

                case 5:
                    input();
                    result = arithmetic.Modulus(a, b);
                    break;


                case 6: // Square
                    powerInput();   
                    result = power.Square(c);
                    isPowerOperation = true;
                    break;

                case 7:
                        powerInput();
                    result = power.Cube(c);
                    isPowerOperation = true;
                    break;

                case 8:
                        powerInput();
                    result = power.SquareRoot(c);
                    isPowerOperation = true;
                    break;

                case 9:
                        powerInput();
                    result = power.CubeRoot(c);
                    isPowerOperation = true;
                    break;


                

                default:
                    Console.WriteLine("Invalid choice.");
                    return;
            }

            if (isPowerOperation)
                Console.WriteLine("Result: " + result);
            else
                Console.WriteLine("Result: " + result);
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a valid numeric choice.");
        }
    }
}
